#!/bin/bash

python -u /home/encryptor/run_server.py
